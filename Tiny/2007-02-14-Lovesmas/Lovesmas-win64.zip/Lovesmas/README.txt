Lovesmas
by Maurycy Zarzycki, 2007-02-14

# About
A game created for GMClan's Liga 24 challenge. The theme was "Valentine Card".
Use your mouse pointer to catch hearts that are thrown into the stage.
The game even features a bug wherein the hearts that fall off the stage also give points (but take away your health).

Original voting thread: https://forum.gmclan.org/topic/4399-tura-13-g%C5%82osowanie/

# Controls
Mouse - Move the cursor

# Contact
https://evidentlycube.com
