Kartka Urodzinowa
(Birthday Card)
by Maurycy Zarzycki, 2007-02-18

Original release thread: https://forum.gmclan.org/topic/4447-tura-14-g%C5%82osowanie/#comment-55163

# About
A game created for GMClan's Liga 24 challenge. The theme was "Birthday Card".
The goal is to keep the mouse pointer over the middle Kulkis and avoid the fists to get as high score as possible.

# Controls
Mouse

# Contact
https://evidentlycube.com
