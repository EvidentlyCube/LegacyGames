Squarbley
by Maurycy Zarzycki, 2007-04-22

# About
A platformer with rudimentary lighting mechanic. 

# Controls
Arrows - Move
Mouse - Aim light

# Contact
https://evidentlycube.com
