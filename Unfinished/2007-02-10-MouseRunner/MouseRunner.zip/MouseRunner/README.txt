Mouse Runner
by Maurycy Zarzycki, 2007-01-10

# About
I... Honestly have no idea what it is supposed to be. I vaguely recall making a game where the goal
was you could never stop moving the mouse so... maybe that's it? But it kinda doesn't work.
Still compiles though!

# Controls
Mouse - Maybe¿? move??

# Contact
https://evidentlycube.com
